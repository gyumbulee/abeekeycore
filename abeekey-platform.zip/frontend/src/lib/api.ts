const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || 'Request failed');
  }

  return res.json();
}

export interface ContactPayload {
  name: string;
  email: string;
  phone?: string;
  company?: string;
  subject?: string;
  message: string;
}

export interface QuotationPayload {
  client_name: string;
  company_name?: string;
  email: string;
  phone?: string;
  service_interest: string;
  project_summary: string;
  budget_range?: string;
}

export const api = {
  getServices: () => request<{ data: { slug: string; name: string; icon: string }[] }>('/services'),
  submitContact: (payload: ContactPayload) =>
    request('/contact', { method: 'POST', body: JSON.stringify(payload) }),
  submitQuotation: (payload: QuotationPayload) =>
    request('/quotation-requests', { method: 'POST', body: JSON.stringify(payload) }),
};
