import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const services = [
  { icon: '💻', title: 'Custom Software Development', desc: 'Bespoke systems built around how your business actually works.' },
  { icon: '📱', title: 'Web & Mobile App Development', desc: 'Fast, accessible, mobile-first products for customers, staff, or the public.' },
  { icon: '☁️', title: 'Cloud & API Solutions', desc: 'Scalable infrastructure and integrations that keep your systems talking to each other.' },
  { icon: '🏦', title: 'FinTech Solutions', desc: 'Payments, ledgers, and financial workflows built to Nigerian regulatory standards.' },
  { icon: '🛡️', title: 'IT Consulting & Cybersecurity', desc: 'Practical guidance and protection for organisations going through digital transformation.' },
  { icon: '🎓', title: 'Training & Capacity Building', desc: 'Hands-on programmes in Excel, digital marketing, design, and core digital skills.' },
  { icon: '🎨', title: 'UI/UX Design', desc: 'Interfaces people actually enjoy using, grounded in research and clear hierarchy.' },
  { icon: '⚙️', title: 'Business Automation', desc: 'Removing repetitive manual work from your operations.' },
  { icon: '🗄️', title: 'Database Design', desc: 'Well-structured, scalable data foundations for growing organisations.' },
];

export default function ServicesPage() {
  return (
    <>
      <Navbar />
      <main className="pt-[150px] pb-24 max-w-6xl mx-auto px-8">
        <div className="max-w-[620px] mb-14">
          <div className="font-mono text-[13px] font-medium text-blue-primary uppercase tracking-widest mb-3">Our Services</div>
          <h1 className="font-heading font-bold text-navy-primary text-4xl mb-4">Full-lifecycle technology services</h1>
          <p className="text-text-soft text-lg">From strategy to deployment and support, one team handles it all.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s) => (
            <div key={s.title} className="bg-surface border border-slate-200/70 rounded-lg p-7">
              <div className="w-11 h-11 rounded-md bg-gradient-to-br from-blue-primary/10 to-blue-accent/15 flex items-center justify-center text-xl mb-5">
                {s.icon}
              </div>
              <h3 className="font-heading font-semibold text-navy-primary text-lg mb-2.5">{s.title}</h3>
              <p className="text-text-soft text-[14.5px]">{s.desc}</p>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </>
  );
}
