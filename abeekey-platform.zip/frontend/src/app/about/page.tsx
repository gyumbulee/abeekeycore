import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main className="pt-[150px] pb-24 max-w-3xl mx-auto px-8">
        <div className="font-mono text-[13px] font-medium text-blue-primary uppercase tracking-widest mb-3">About Abeekey</div>
        <h1 className="font-heading font-bold text-navy-primary text-4xl mb-6">
          Technology that moves business forward.
        </h1>
        <p className="text-text-soft text-lg mb-6">
          Abeekey (ASGL Limited, RC 8152454) is a Nigerian technology and business solutions company founded
          by Ibrahim Muazu Muazu, based in Wase, Plateau State. We design, build, and maintain secure, scalable,
          and user-focused digital solutions for businesses, governments, and institutions across Nigeria and Africa.
        </p>
        <p className="text-text-soft text-lg">
          Our vision is to become one of Africa&apos;s most trusted technology companies — building software that
          helps businesses, governments, and individuals thrive in the digital economy.
        </p>
      </main>
      <Footer />
    </>
  );
}
