import Link from 'next/link';

const links = [
  { href: '/services', label: 'Services' },
  { href: '/about', label: 'About' },
  { href: '/industries', label: 'Industries' },
  { href: '/contact', label: 'Contact' },
];

export default function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-navy-primary/70 backdrop-blur-lg border-b border-white/10">
      <div className="max-w-6xl mx-auto px-8 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5 font-heading font-bold text-xl text-white">
          <span className="w-8 h-8 rounded-[9px] bg-gradient-to-br from-blue-accent to-navy-secondary flex items-center justify-center text-sm shadow-inner">
            🔷
          </span>
          Abeekey
        </Link>

        <div className="hidden md:flex gap-9 text-sm font-medium text-white/75">
          {links.map((link) => (
            <Link key={link.href} href={link.href} className="hover:text-white transition-colors">
              {link.label}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <Link
            href="/contact"
            className="hidden sm:inline-flex px-5 py-2.5 rounded-sm text-sm font-semibold text-white/85 border border-white/20 hover:bg-white/5 transition-colors"
          >
            Contact
          </Link>
          <Link
            href="/contact"
            className="inline-flex px-5 py-2.5 rounded-sm text-sm font-semibold text-white bg-gradient-to-br from-blue-primary to-blue-accent shadow-[0_4px_18px_rgba(37,99,235,0.35)] hover:-translate-y-px transition-transform"
          >
            Get a Quote
          </Link>
        </div>
      </div>
    </nav>
  );
}
