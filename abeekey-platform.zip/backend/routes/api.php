<?php

use App\Http\Controllers\ContactController;
use App\Http\Controllers\QuotationController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\TrainingController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public API Routes — Abeekey Marketing Site (Phase 1)
|--------------------------------------------------------------------------
| These endpoints back the Next.js frontend. All are unauthenticated/public
| since Phase 1 has no client portal or login yet.
*/

Route::get('/services', [ServiceController::class, 'index']);

Route::post('/contact', [ContactController::class, 'store']);

Route::post('/quotation-requests', [QuotationController::class, 'store']);

Route::post('/training/applications', [TrainingController::class, 'store']);
Route::get('/training/courses', [TrainingController::class, 'courses']);
